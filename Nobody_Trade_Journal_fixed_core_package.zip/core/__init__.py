"""Nobody Trade Journal core package."""
